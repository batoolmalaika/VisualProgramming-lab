﻿using System;
using System.Collections.Generic;


namespace lab_mid
{
   
        public class Studentclub
        {
            private static double Budget;
            private static string President;
            private static string VicePresident;
            private static string GeneralSeceratary;
            private static string FinanceSeceratary;

            public static void setBudget(double a)
            {

                Budget = a;

            }

            public static void setPresident(string b)
            {

                President = b;

            }

            public static void setVicePresident(string d)
            {

                VicePresident = d;

            }
            public static void setGeneralSeceratary(string f)
            {

                GeneralSeceratary = f;

            }
            public static void setFinanceSeceratary(string h)
            {

                FinanceSeceratary = h;

            }

            public static double getBudget()
            {

                return Budget;

            }

            public static string getPresident()
            {

                return President;

            }

            public static string getVicePresident()
            {

                return VicePresident;

            }
            public static string getGeneralSeceratary()
            {

                return GeneralSeceratary;

            }
            public static string getFinanceSeceratary()
            {

                return FinanceSeceratary;

            }


            static void FundSociey()
            {

                return;

            }

            static void DispenseFunds()
            {

                return;

            }


            static void RegisterSociety()
            {

                return;

            }

            static void DisplaySocieties()
            {

                return;

            }






        }


        public class Society 
        {
            private static string Name;
            private static int Contact;

            public static void setName(string k)
            {

                Name = k;

            }

            public static void setContact(int l)
            {

                Contact = l;

            }



            public static string getName()
            {

                return Name;

            }

            public static int getContact()
            {

                return Contact;

            }

            static void AddActivity()
            {

                return;

            }

            static void ListEvents()
            {

                return;

            }


        }

        public class FundedSociety : Society

        {
            private static double FundingAmount;



            public static void setFundingAmount(double kv)
            {

                FundingAmount = kv;

            }
            public static double getFundingAmount()
            {

                return FundingAmount;

            }
        }
        public class NONFundedSociety : Society
        {
            private static double FundingAmount;



            public static void setFundingAmount(double kv)
            {

                FundingAmount = kv;

            }
            public static double getFundAmount()
            {

                return FundingAmount;

            }


        }

        public class ClubRole
        { 
        
            private static string Name;
            private static string Role;
            private static string ContactInfo;


            public static void setName(string z)
            {

                Name  = z;

            }
            public static string getName()
            {

                return Name;

            }


            public static void setRole(string y)
            {

                Role = y;

            }
            public static string getRole()
            {

                return Role;

            }


            public static void setContactInfo(string x)
            {

                ContactInfo = x;

            }
            public static string getContactInfo()
            {

                return ContactInfo;

            }

        }

        class Program
        {


            static void Main(string[] args)
            {

                Console.WriteLine("Student Club Management System ");
                Console.WriteLine("_________________________");
                Console.WriteLine("1. Register a new society");
                Console.WriteLine("2. Allocate funding to society ");
                Console.WriteLine("3. Register an event for the society ");
                Console.WriteLine("4. Display socity funding information ");
                Console.WriteLine("5. Display event for a society ");
                Console.WriteLine("6.  Exit");


                Console.ReadLine();
                int choice 
                {


                    case 1:
                        {

                        Console.WriteLine("New Sociey :");


                    }

                     case 2:
                        {



                    }

                     case 3:
                        {



                    }

                     case 4:
                        {



                    }


                     case 5
                        {



                    }

                     case 6
                        {



                         }




                }










            }


        }





    
}
